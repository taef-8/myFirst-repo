<?php
include("databse.php"); 
$id = $_GET['id'];
$delete = mysqli_query($con, "delete from `meals` where mealID = '$id'");
		 echo "<script>alert('Selected meal deleted successfully');"; 
		 echo "window.location.href = 'admin.html' </script>";
?>