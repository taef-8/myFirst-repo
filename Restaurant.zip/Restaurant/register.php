<?php
include ("databse.php");
if($_POST['nm'] == "" || $_POST['ps'] == "" || $_POST['em'] == "" || $_POST['mb'] == "" || $_POST['adrs'] == "")
{
	echo "<script>alert('Please fill all required data');"; 
	echo "window.location.href = 'register.html' </script>";
}
else {
	//// read the inputs 
	$nm = $_POST['nm'];
	$em = $_POST['em'];
	$ps = $_POST['ps'];
	$mb = $_POST['mb'];
	$adrs = $_POST['adrs'];
	//1. check in admin table 
	$sel = mysqli_query($con, "select * from `admin` where adminEmail = '$em' ");
	$num_rows = mysqli_num_rows($sel); 
	if($num_rows != 0)
	{
		echo "<script>alert('Email already used, try again');"; 
		echo "window.location.href = 'register.html' </script>";
	}
	else 
	{
		//2. check in customer table 
		$sel = mysqli_query($con, "select * from `customer` where custEmail = '$em' ");
		$num_rows = mysqli_num_rows($sel); 
		if($num_rows != 0)
		{
			echo "<script>alert('Email already used, try again');"; 
			echo "window.location.href = 'register.html' </script>";
		}
		else 
		{
			$insert = mysqli_query($con, "insert into `customer` (`custName`, `custAddress`, `custEmail`, `custMobile`, `custPass`) values ('$nm', '$adrs', '$em', '$mb' , '$ps')");
			echo "<script>alert('Successful add new Customer');"; 
			echo "window.location.href = 'login.html' </script>";
		}
	} 
 }
?>