<?php
$con = mysqli_connect('localhost','root','', 'rest') or die ("not connect");
 mysqli_query($con,"set names utf8");
?>