<?php 
session_start();
if(isset($_SESSION['CUST'])){
	$custID = $_SESSION['CUST']; 
?>
<!DOCTYPE html>
<html>
<head>
<title>Online Restaurant</title>
	<link href="style.css" rel="stylesheet" type="text/css" media="all" />

</head>
<body>
<div class="div-back" align="center" id="container">
<div align="center"><img src="name.png" width="500" height="150"></div>

<table width="80%" align="center">
<tr><td width="20%">&nbsp;</td>
<td align="center" width="60%"><h2 style="font-size:36px; color:#333333;"><b>Restaurant Menu</b></h2></td>
<td width="20%">&nbsp;</td></tr>
<tr><td width="20%">&nbsp;</td>
<td align="center" width="60%">

<table align="center" width="80%" cellspacing="20" cellpadding="20">
<?php
/// read all meals found
include('databse.php'); 
$i =0; 
$select = mysqli_query($con, "select * from `meals`"); 
while($found = mysqli_fetch_array($select)){
?>
<td><img src="<?php echo $found['mealImage']; ?>" width="150" height="100">
<p align="center"><?php echo $found['mealName']; ?></p>
<p align="center"><a href="payment.php?id=<?php echo $found['mealID']; ?>&prc=<?php echo $found['mealPrice']; ?>">Order Meal</a></p></td>
<?php
	$i = $i+1;
	if($i == 3)
	{
		echo "</tr><tr>";
	}
}
?></table>

<br><br><br><br>
</td><td width="20%">&nbsp;</td></tr>
</table>
</div>
</body>
</html>
<?php
} else{
	 echo "<script>alert('You should login to the customer account');"; 
	 echo "window.location.href = 'login.html' </script>";
}
?>
