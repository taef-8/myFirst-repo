<?php 
session_start();
if(isset($_SESSION['CUST'])){
	$custID = $_SESSION['CUST']; 
	$prc = $_GET['prc'];
	$mID = $_GET['id'];
?>
<!DOCTYPE html>
<html>
<head>
<title>Online Restaurant</title>
	<link href="style.css" rel="stylesheet" type="text/css" media="all" />

</head>
<body>
<div class="div-back" align="center" id="container">
<table width="80%" align="center">
<tr><td width="20%">&nbsp;</td>
<td width="60%"><img src="name.png" width="500" height="150"></td>
<td width="20%">&nbsp;</td></tr>
<tr><td width="20%">&nbsp;</td>
<td align="center" width="60%"><h2 style="font-size:36px; color:#333333;"><b>Order Payment</b></h2></td>
<td width="20%">&nbsp;</td></tr>
<tr><td width="20%">&nbsp;</td>
<td align="center" width="60%"><form action="payment.php" method="post">
<input type="text" class="class-input" id="qty" name="qty" placeholder="Quantity" required>
<br><br>
<input type="text" class="class-input" id="prc" name="prc" value="<?php echo $prc; ?>">
<input name="mealID" type="hidden" value="<?php echo $mID; ?>">
<br><br>
<input name="" type="submit" value="Submit Order" class="class-button">&nbsp;&nbsp;
<input name="" type="reset" value="Cancel" class="class-button"> 
</form><br><br><br><br>
<?php
if(isset($_POST['qty'])){
	if(is_numeric($_POST['qty'])){
		include("databse.php"); 
		$custID = $_SESSION['CUST'];
		$date = date('y-m-d');
		$qty = $_POST['qty'];
		$prc = $_POST['prc'];
		$total = $qty * $prc; 
		$order = mysqli_query($con, "insert into `orders` (orderDate, custID, mealID, `quantity`) values ('$date', '$custID', '$mID','$qty' )");
				 echo "<script>alert('New Order submit successfully, Total Price: $total');"; 
				 echo "window.location.href = 'customer.html' </script>";
	}else {
		 echo "<script>alert('Please enter numeric quantity');"; 
		 echo "window.location.href ='view_meals.php'</script>";
	}
}
?>
</td><td width="20%">&nbsp;</td></tr>
</table>
</div>
</body>
</html>
<?php
} else{
	 echo "<script>alert('You should login to the customer account');"; 
	 echo "window.location.href = 'login.html' </script>";
}
?>