<?php
//// destrory the session and release all the session parameters then navigate to the index page 
session_start();
session_destroy();
header("location:index.html");
?>