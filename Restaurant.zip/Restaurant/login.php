<?php
include ("databse.php");
if($_POST['ps'] == "" || $_POST['em'] == "")
{
	echo "<script>alert('Please fill all required data');"; 
	echo "window.location.href = 'login.html' </script>";
}
else {
	//// read the inputs 
	$em = $_POST['em'];
	$ps = $_POST['ps'];
	//1. check in admin table 
	$sel = mysqli_query($con, "select * from `admin` where adminEmail = '$em' and adminPass = '$ps' ");
	$num_rows = mysqli_num_rows($sel); 
	if($num_rows != 0)
	{
		session_start();
		$found = mysqli_fetch_array($sel);
		$_SESSION['ADMIN'] = $found['adminID'];
		echo "<script>alert('Administrator Login Successfully');"; 
		echo "window.location.href = 'admin.html' </script>";
	}
	else 
	{
		//2. check in customer table 
		$sel = mysqli_query($con, "select * from `customer` where custEmail = '$em' and custPass = '$ps' ");
		$num_rows = mysqli_num_rows($sel); 
		if($num_rows != 0)
		{
			session_start();
			$found = mysqli_fetch_array($sel);
			$_SESSION['CUST'] = $found['custID'];
			echo "<script>alert('Customer Login Successfully');"; 
			echo "window.location.href = 'customer.html' </script>";
		}
		else 
		{
			echo "<script>alert('Email or Password error, try again');"; 
			echo "window.location.href = 'login.html' </script>";
		}
	} 
 }
?>