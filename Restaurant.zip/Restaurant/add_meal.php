<?php
session_start();
if(isset($_SESSION['ADMIN'])){
include("databse.php"); 
if($_POST['nm'] == "" || $_POST['prc'] == "" || $_FILES['image']['size'] == 0)
{
	echo "<script>alert('Please fill all required data');"; 
	echo "window.location.href = 'add_meal.html' </script>";
}
else if(!is_numeric($_POST['prc'])){
	echo "<script>alert('Meal price should be numbers only');"; 
	echo "window.location.href = 'add_meal.html' </script>";
}
else {
	//// read the inputs 
	$name = $_POST['nm'];
	$prc = $_POST['prc'];
     if($_FILES['image']['type'] != "image/png" && $_FILES['image']['type'] != "image/gif" && $_FILES['image']['type'] != "image/jpg" && $_FILES['image']['type'] != "image/jpeg")
	 {
		  echo "<script>alert('Meal image must be image format, please try again!');"; 
		  echo "window.location.href = 'add_meal.html' </script>";
	 } 
	 else 
	 {
			$tmp_name = $_FILES['image']['tmp_name'];
			$file_name = $_FILES['image']['name'];
			//// to upload meal image  ////
			$read  = fopen($tmp_name, 'r');
			$data = fread($read, filesize($tmp_name));
			$data = addslashes($data);
			fclose($read);
					///////////////////////
			$img = "images/$file_name";
			move_uploaded_file($tmp_name,"$img");
			$insert = mysqli_query($con, "insert into `meals` (mealName, mealPrice, mealImage) values ('$name', '$prc', '$img')");
		  echo "<script>alert('New Meal added successfully');"; 
		  echo "window.location.href = 'admin.html' </script>";
	}
}
}
else 
{
		 echo "<script>alert('You should login to the administrator account');"; 
		 echo "window.location.href = 'login.html' </script>";
}
?>