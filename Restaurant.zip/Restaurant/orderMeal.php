<?php
session_start();
include("databse.php"); 
$id = $_GET['id'];
$custID = $_SESSION['CUST'];
$date = date('y-m-d');
$order = mysqli_query($con, "insert into `orders` (orderDate, custID, mealID) values ('$date', '$custID', '$id')");
		 echo "<script>alert('New Order submit successfully');"; 
		 echo "window.location.href = 'customer.html' </script>";
?>